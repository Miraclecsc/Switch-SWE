"""Restore only two legacy stdlib aliases needed by the retained attrs tests."""
import collections as _collections
from collections import abc as _abc

for _name in ("Mapping", "Sequence"):
    if not hasattr(_collections, _name):
        setattr(_collections, _name, getattr(_abc, _name))
